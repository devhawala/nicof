This archive contains the files for updating a NICOF 0.6.0 installation
to version 0.7.0

Changes from version 0.6.0:

- the socket API now has restricted support for DATAGRAM sockets
  (no ICMP or the like, as not possible with plain java sockets)

- the socket API now allows to assign individual IP addresses to
  virtual machines through a naming convention in the hosts file
  or (private) DNS

- new HACC tool allowing to access arbitrary files on the host
  filesystem from CMS 

However, this archive does not contain the setup files for the 3
installation variants available in the 0.6.0 version (manual, normal
and playground installation). Chapter 2 of the documentation is insofar
misleading and should be ignored regarding the presence of setup files,
as these setups were never created for 0.7.0.

Instead, one of the 3 setup variants of version 0.6.0 must first
be installed in a VM/370 Sixpack system and the files of this archive
then copied over the corresponding items from the subdirectories in
this archive:

- the tape files in directory "cms" contain the updates for the
  NICOF binaries resp. sources, the tapes were written with VMFPLC2

- the directory "java" contains the eclipse project with the java
  sources for the external proxies

- the "doc" directory has the MS-Word source and PDF for the
  documentation of NICOF 0.7.0

- the "vm370_extension" directory contains the files to update a
  playground installation by copying its content in the base 
  directory of the VM/370 Sixpack installation

Hoping that someone will find this useful
Dr. Hans-Walter Latz, Berlin, 2017-09-19
