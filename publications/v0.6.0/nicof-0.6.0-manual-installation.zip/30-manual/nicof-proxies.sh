#
# Launch the NICOF process with the outside proxies
#

# check that java is on the PATH
#
java -version > /dev/null 2>&1
if [ $? -ne 0 ] ;
then
  echo "##"
  echo "## java not found to start NICOF"
  echo "## ... ABORTING startup"
  echo "##"
  exit 1
fi

if [ .$1 = ".start" ] ;
then
  echo "... starting NICOF"
  cd nicof
  java -cp .:nicof.jar dev.hawala.vm370.commproxy.CommProxy nicofpxy.properties tcpip.properties > ../nicof.log &
  exit 0
fi

if [ .$1 = ".stop" ] ;
then
  echo "... stopping NICOF" ;
  ps -ef | grep nicof | grep java | grep -v grep | awk '{system("kill -9 "$2" > /dev/null");}' > /dev/null 2> /dev/null
  exit 0
fi

echo "Usage: $0 start|stop"
exit 2


