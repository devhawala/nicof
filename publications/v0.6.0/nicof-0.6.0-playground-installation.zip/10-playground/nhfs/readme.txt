
NHFS user directories will be created in this directory
